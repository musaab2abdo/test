<?php
use App\Http\Controllers\GameController;
use App\Http\Controllers\PlayerController;
use App\Http\Controllers\RoomController;
use Illuminate\Support\Facades\Route;

Route::get('/start-game/{roomId}', [GameController::class, 'startGame']);
Route::post('/add-player', [PlayerController::class, 'addPlayer']);
Route::post('/create-room', [RoomController::class, 'createRoom']);
